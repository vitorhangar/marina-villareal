<?php

/**
 * @author OnTheGo Systems
 */
class WPML_TM_ATE_Models_Language {
	public $code;
	public $name;
}